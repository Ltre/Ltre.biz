const $=id=>document.getElementById(id);let channels=[];const token=()=>localStorage.getItem('adminToken')||'';
async function api(path,init={}){const h={'content-type':'application/json','x-admin-token':token(),...(init.headers||{})};const r=await fetch(path,{...init,headers:h});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||`HTTP ${r.status}`);return d}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function dt(v){return v?new Date(v).toLocaleString():''}
function nullableNumber(v){const s=String(v??'').trim();return s===''?null:Number(s)}
async function health(){try{const d=await fetch('/health').then(r=>r.json());$('health').textContent=d.ok?'服务正常':'异常'}catch{$('health').textContent='不可达'}}
function protocolOptions(current){return ['openai_compat','anthropic','gemini','workers_ai'].map(x=>`<option value="${x}" ${x===current?'selected':''}>${x}</option>`).join('')}
function renderModel(m){return `<div class="model-editor" data-model-id="${m.id}">
  <div class="model-state"><b>#${m.id}</b><span class="pill">${m.enabled?'启用':'停用'}</span>${m.capabilities?.vision?'<span class="pill">视觉</span>':''}</div>
  <input id="mid-${m.id}" value="${esc(m.model_id)}" placeholder="模型 ID">
  <input id="mdisplay-${m.id}" value="${esc(m.display_name||'')}" placeholder="显示名">
  <label><input id="mvision-${m.id}" type="checkbox" ${m.capabilities?.vision?'checked':''}>视觉</label>
  <input id="min-${m.id}" type="number" step="0.0001" value="${m.input_cost_per_million??''}" placeholder="输入$/M">
  <input id="mout-${m.id}" type="number" step="0.0001" value="${m.output_cost_per_million??''}" placeholder="输出$/M">
  <button onclick="saveModel(${m.id})">保存模型</button>
  <button onclick="toggleModel(${m.id},${m.enabled?0:1})">${m.enabled?'停用':'启用'}</button>
  <button class="danger" onclick="deleteModel(${m.id})">删除</button>
</div>`}
async function loadChannels(){const d=await api('/api/admin/channels');channels=d.channels||[];$('channels').innerHTML=channels.map(c=>`<div class="channel">
  <div class="row"><b>${esc(c.name)}</b><span class="pill">${esc(c.slug)}</span><span class="pill">${esc(c.protocol)}</span><span class="muted">${c.enabled?'启用':'停用'} · 凭据${c.has_credentials?'已配置':'未配置'}</span></div>
  <div class="channel-editor">
    <input id="name-${c.id}" value="${esc(c.name)}" placeholder="渠道名称">
    <select id="protocol-${c.id}">${protocolOptions(c.protocol)}</select>
    <input id="base-${c.id}" value="${esc(c.base_url||'')}" placeholder="Base URL">
    <input id="path-${c.id}" value="${esc(c.api_path||'')}" placeholder="API Path">
    <input id="notes-${c.id}" value="${esc(c.notes||'')}" placeholder="备注">
    <input id="key-${c.id}" type="password" placeholder="新 API Key（留空不改）">
    <textarea id="headers-${c.id}" placeholder='新额外请求头 JSON；与新 Key 一起覆盖凭据'></textarea>
    <button onclick="saveChannel(${c.id})">保存渠道</button>
    <button onclick="toggleChannel(${c.id},${c.enabled?0:1})">${c.enabled?'停用渠道':'启用渠道'}</button>
  </div>
  <div class="model-list">${(c.models||[]).length?(c.models||[]).map(renderModel).join(''):'<span class="muted">尚未添加模型</span>'}</div>
  <div class="row add-model"><input id="model-${c.id}" placeholder="模型 ID"><input id="display-${c.id}" placeholder="显示名"><label><input id="vision-${c.id}" type="checkbox">视觉</label><input id="in-${c.id}" type="number" step="0.0001" placeholder="输入$/M"><input id="out-${c.id}" type="number" step="0.0001" placeholder="输出$/M"><button onclick="addModel(${c.id})">加模型</button></div>
</div>`).join('')}
window.saveChannel=async id=>{let headers={};const raw=$(`headers-${id}`).value.trim();if(raw){try{headers=JSON.parse(raw)}catch{return alert('额外请求头必须是 JSON')}}const key=$(`key-${id}`).value.trim();const body={name:$(`name-${id}`).value.trim(),protocol:$(`protocol-${id}`).value,base_url:$(`base-${id}`).value.trim(),api_path:$(`path-${id}`).value.trim(),notes:$(`notes-${id}`).value.trim()};if(key||raw)body.credentials={api_key:key,headers};await api(`/api/admin/channels/${id}`,{method:'PATCH',body:JSON.stringify(body)});await loadChannels();alert('渠道已更新')}
window.toggleChannel=async(id,on)=>{await api(`/api/admin/channels/${id}`,{method:'PATCH',body:JSON.stringify({enabled:!!on})});await loadChannels();await loadUsers()}
window.addModel=async id=>{const modelId=$(`model-${id}`).value.trim();if(!modelId)return alert('模型 ID 不能为空');await api(`/api/admin/channels/${id}/models`,{method:'POST',body:JSON.stringify({model_id:modelId,display_name:$(`display-${id}`).value.trim(),capabilities:{vision:$(`vision-${id}`).checked},input_cost_per_million:nullableNumber($(`in-${id}`).value),output_cost_per_million:nullableNumber($(`out-${id}`).value)})});await loadChannels();await loadUsers()}
window.saveModel=async id=>{const modelId=$(`mid-${id}`).value.trim();if(!modelId)return alert('模型 ID 不能为空');await api(`/api/admin/models/${id}`,{method:'PATCH',body:JSON.stringify({model_id:modelId,display_name:$(`mdisplay-${id}`).value.trim(),capabilities:{vision:$(`mvision-${id}`).checked},input_cost_per_million:nullableNumber($(`min-${id}`).value),output_cost_per_million:nullableNumber($(`mout-${id}`).value)})});await loadChannels();await loadUsers();alert('模型已更新')}
window.toggleModel=async(id,on)=>{await api(`/api/admin/models/${id}`,{method:'PATCH',body:JSON.stringify({enabled:!!on})});await loadChannels();await loadUsers()}
window.deleteModel=async id=>{const m=channels.flatMap(c=>c.models||[]).find(x=>x.id===id);const name=m?.display_name||m?.model_id||`#${id}`;if(!confirm(`确定删除模型“${name}”吗？\n该模型对应的用户授权会一并删除，但历史用量记录保留。`))return;await api(`/api/admin/models/${id}`,{method:'DELETE'});await loadChannels();await loadUsers()}
async function loadUsers(){const d=await api('/api/admin/users');const allModels=channels.flatMap(c=>(c.models||[]).map(m=>({...m,channel:c})));$('users').innerHTML=(d.users||[]).map(u=>`<div class="user"><div class="row"><b>${esc(u.phone)}</b><span class="pill">AI ${u.ai_enabled?'启用':'暂停'}</span><span class="muted">调用 ${u.calls||0} · Tokens ${u.tokens||0} · $${Number(u.cost||0).toFixed(5)} · 最近登录 ${dt(u.last_login_at)}</span><button onclick="toggleUser(${u.id},${u.ai_enabled?0:1})">${u.ai_enabled?'暂停 AI':'启用 AI'}</button></div><div class="models">${allModels.map(m=>`<label class="model"><input type="checkbox" class="perm-${u.id}" value="${m.id}" ${(u.model_ids||[]).includes(m.id)?'checked':''}>${esc(m.channel.name)} / ${esc(m.model_id)} ${!m.channel.enabled||!m.enabled?'（当前停用）':''}</label>`).join('')}</div><button onclick="savePerm(${u.id})">保存该用户模型权限</button></div>`).join('')}
window.toggleUser=async(id,on)=>{await api(`/api/admin/users/${id}`,{method:'PATCH',body:JSON.stringify({ai_enabled:!!on})});await loadUsers()}
window.savePerm=async id=>{const ids=[...document.querySelectorAll(`.perm-${id}:checked`)].map(x=>Number(x.value));await api(`/api/admin/users/${id}/permissions`,{method:'PUT',body:JSON.stringify({model_ids:ids})});alert(`已授权 ${ids.length} 个模型`)}
async function loadUsage(){const p=new URLSearchParams();if($('from').value)p.set('from',new Date($('from').value).toISOString());if($('to').value)p.set('to',new Date($('to').value).toISOString());const d=await api('/api/admin/usage?'+p);$('usage').innerHTML=`<table><thead><tr><th>用户</th><th>模型</th><th>调用</th><th>输入</th><th>输出</th><th>总 Token</th><th>估算费用</th><th>错误</th></tr></thead><tbody>${(d.rows||[]).map(r=>`<tr><td>${esc(r.phone)}</td><td>${esc(r.public_model_id)}</td><td>${r.calls}</td><td>${r.input_tokens||0}</td><td>${r.output_tokens||0}</td><td>${r.total_tokens||0}</td><td>$${Number(r.estimated_cost_usd||0).toFixed(6)}</td><td>${r.errors||0}</td></tr>`).join('')}</tbody></table>`}
async function refreshAll(){await health();await loadChannels();await loadUsers();await loadUsage()}
$('saveToken').onclick=()=>{localStorage.setItem('adminToken',$('adminToken').value);refreshAll().catch(e=>alert(e.message))};$('refreshAll').onclick=()=>refreshAll().catch(e=>alert(e.message));$('loadUsage').onclick=()=>loadUsage().catch(e=>alert(e.message));
$('addChannel').onclick=async()=>{let headers={};try{headers=$('chHeaders').value.trim()?JSON.parse($('chHeaders').value):{}}catch{return alert('额外请求头必须是 JSON')};await api('/api/admin/channels',{method:'POST',body:JSON.stringify({name:$('chName').value.trim(),slug:$('chSlug').value.trim(),protocol:$('chProtocol').value,base_url:$('chBase').value.trim(),api_path:$('chPath').value.trim(),credentials:{api_key:$('chKey').value.trim(),headers}})});await loadChannels();alert('渠道已新增')};
$('diagnostics').onclick=async()=>{$('diag').textContent='运行中…';try{$('diag').textContent=JSON.stringify(await api('/api/admin/diagnostics',{method:'POST'}),null,2)}catch(e){$('diag').textContent=e.message}};
$('devRegister').onclick=async()=>{try{$('devOut').textContent=JSON.stringify(await fetch('/api/dev/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({phone:$('devPhone').value.trim()})}).then(r=>r.json()),null,2)}catch(e){$('devOut').textContent=e.message}};
$('adminToken').value=token();health();if(token())refreshAll().catch(e=>$('diag').textContent=e.message);
